import React from 'react';
import { Spinner } from 'flowbite-react';

const BtnLoader = () => {
  return (
    <Spinner color="gray" size="sm" />
  );
};

export default BtnLoader;