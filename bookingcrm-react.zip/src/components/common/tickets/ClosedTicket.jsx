import React, { useEffect, useState } from 'react';
import axios from "axios";

const ClosedTicket = () => {
    //const navigate = useNavigate();
    
    const [loading, setLoading] = useState([false]);

    useEffect(() => {

    }, []);

    /***********************************************************************/
    /***********************************************************************/

    return (
        <>
            <div className="">
                This is closed ticket
            </div>
        </>

    );
};

export default ClosedTicket;