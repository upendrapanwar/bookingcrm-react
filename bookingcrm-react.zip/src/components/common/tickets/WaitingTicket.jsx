import React, { useEffect, useState } from 'react';
import axios from "axios";

const WaitingTicket = () => {
    //const navigate = useNavigate();
    
    const [loading, setLoading] = useState([false]);

    useEffect(() => {

    }, []);

    /***********************************************************************/
    /***********************************************************************/

    return (
        <>
            <div className="">
                This is waiting ticket
            </div>
        </>

    );
};

export default WaitingTicket;