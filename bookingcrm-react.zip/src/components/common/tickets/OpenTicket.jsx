import React, { useEffect, useState } from 'react';
import axios from "axios";

const OpenTicket = () => {
    //const navigate = useNavigate();
    
    const [loading, setLoading] = useState([false]);

    useEffect(() => {

    }, []);

    /***********************************************************************/
    /***********************************************************************/

    return (
        <>
            <div className="">
                This is open ticket
            </div>
        </>

    );
};

export default OpenTicket;
