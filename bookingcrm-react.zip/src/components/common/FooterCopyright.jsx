import React from "react";

const FooterCopyright = () => {
    return(
        <>
            <div className="copyright pt-25 pb-25">
                <div className="container ">
                    <p>CITB SMSTS/SSSTS ONLINE TRAINING | VAT No. 382 2073 10 | VAT Charged at 20% | Calls Are Recorded For
                            Training & Monitoring Purposes.<br />
                            © 2020 FULL STACK INTERNATIONAL LTD is registered in England and Wales.
                    </p>
                </div>
            </div>
        </>
    );
}

export default FooterCopyright;